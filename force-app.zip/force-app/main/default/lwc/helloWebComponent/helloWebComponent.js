import { LightningElement } from 'lwc';

export default class HelloWebComponent extends LightningElement {}